chrome.privacy.network.webRTCMultipleRoutesEnabled.set({'value': false});
